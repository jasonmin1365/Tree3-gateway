import { isMap, isSeq, parseDocument } from 'yaml'
import {
  buildResidentialProfile,
  type ResidentialListenerInput,
  type ResidentialProfileInput,
} from './residentialProfile'

type Listener = ResidentialListenerInput & { sourceIndex?: number }
export type ResidentialEditInput = Omit<ResidentialProfileInput, 'listeners'> & {
  listeners: Listener[]
}

function readProfile(content: string) {
  const doc = parseDocument(content)
  if (doc.errors.length || !isMap(doc.contents)) return
  const proxies = doc.get('proxies')
  const listeners = doc.get('listeners')
  if (!isSeq(proxies) || !isSeq(listeners) || !listeners.items.length) return
  const first = listeners.items[0]
  const name = isMap(first) && first.get('proxy')
  if (typeof name !== 'string' || !name) return
  const matches = proxies.items.filter((item) => isMap(item) && item.get('name') === name)
  const node = matches[0]
  if (matches.length !== 1 || !isMap(node) || node.get('type') !== 'socks5') return
  const host = node.get('server')
  const port = node.get('port')
  const username = node.get('username') ?? ''
  const password = node.get('password') ?? ''
  if (typeof host !== 'string' || !isPort(port) ||
      typeof username !== 'string' || typeof password !== 'string') return

  const rows: Listener[] = []
  for (const [sourceIndex, item] of listeners.items.entries()) {
    if (!isMap(item) || item.get('type') !== 'http' || item.get('proxy') !== name) return
    const listenerName = item.get('name')
    const listen = item.get('listen')
    const listenerPort = item.get('port')
    if (typeof listenerName !== 'string' || typeof listen !== 'string' || !isPort(listenerPort)) return
    const comment = item.commentBefore?.trim()
    let label = listenerName === 'gpt-in' ? 'GPT' : listenerName === 'claude-in' ? 'Claude' : listenerName
    if (comment?.startsWith('"')) {
      try {
        const value = JSON.parse(comment)
        if (typeof value === 'string') label = value
      } catch { /* keep the default label */ }
    }
    rows.push({ label, name: listenerName, listen, port: String(listenerPort), sourceIndex })
  }

  const groups = doc.get('proxy-groups')
  const providers = doc.get('proxy-providers')
  const dialer = node.get('dialer-proxy')
  let provider
  let subscriptionUrl = ''
  if (dialer != null) {
    if (typeof dialer !== 'string' || !isSeq(groups) || !isMap(providers)) return
    const matching = groups.items.filter((g) => isMap(g) && g.get('name') === dialer)
    const group = matching[0]
    if (matching.length !== 1 || !isMap(group) || group.get('type') !== 'select') return
    const use = group.get('use')
    const key = isSeq(use) && use.items.length === 1 && use.get(0)
    if (typeof key !== 'string' || group.has('proxies')) return
    const entry = providers.get(key)
    if (!isMap(entry) || entry.get('type') !== 'http') return
    const url = entry.get('url')
    if (typeof url !== 'string') return
    provider = entry
    subscriptionUrl = url
  }
  const input: ResidentialEditInput = {
    host, port: String(port), username, password, chainEnabled: Boolean(provider),
    subscriptionUrl, listeners: rows,
  }
  return { doc, node, name, proxies, listeners, groups, providers, provider, input }
}

const isPort = (value: unknown): value is number | string =>
  (typeof value === 'number' || typeof value === 'string') && /^\d{1,5}$/.test(String(value))

export function readResidentialProfileInput(content: string) {
  try { return readProfile(content)?.input } catch { return undefined }
}

export function updateResidentialProfile(content: string, input: ResidentialEditInput): string {
  const current = readProfile(content)
  if (!current) throw new Error('unsupported_residential_profile')
  const next = readProfile(buildResidentialProfile(input))
  if (!next) throw new Error('invalid_residential_profile')
  const { doc, node, name, listeners, groups, providers, provider, proxies } = current
  for (const key of ['server', 'port', 'username', 'password']) {
    if (next.node.has(key)) node.set(key, next.node.get(key))
    else node.delete(key)
  }
  if (!input.chainEnabled) {
    // The old group/provider may still be used by other rules or nodes.
    node.delete('dialer-proxy')
  } else if (provider) {
    provider.set('url', next.input.subscriptionUrl)
  } else {
    if ((groups != null && !isSeq(groups)) || (providers != null && !isMap(providers)))
      throw new Error('unsupported_chain_sections')
    const existingGroups = isSeq(groups) ? groups.items : []
    const unique = (base: string, taken: (name: string) => boolean) => {
      let name = base
      for (let suffix = 2; taken(name); suffix++) name = `${base}-${suffix}`
      return name
    }
    const providerName = unique('Tree3-Airport', (key) => isMap(providers) && providers.has(key))
    const groupName = unique('Tree3-Airport-Hop', (key) =>
      [...existingGroups, ...proxies.items].some((item) => isMap(item) && item.get('name') === key),
    )
    const entry = { type: 'http', url: next.input.subscriptionUrl, interval: 3600, proxy: 'DIRECT', header: { 'User-Agent': ['clash.meta'] } }
    const group = { name: groupName, type: 'select', use: [providerName], 'empty-fallback': 'REJECT' }
    if (isMap(providers)) providers.set(providerName, doc.createNode(entry))
    else doc.set('proxy-providers', { [providerName]: entry })
    if (isSeq(groups)) groups.add(doc.createNode(group))
    else doc.set('proxy-groups', [group])
    node.set('dialer-proxy', groupName)
  }
  listeners.items = next.input.listeners.map((row, index) => {
    const sourceIndex = input.listeners[index]?.sourceIndex
    const old = sourceIndex === undefined ? undefined : listeners.items[sourceIndex]
    const item = isMap(old) ? old : doc.createNode({ type: 'http', proxy: name })
    item.set('name', row.name)
    item.set('listen', row.listen)
    item.set('port', Number(row.port))
    const label = input.listeners[index]?.label.trim()
    const previousLabel = sourceIndex === undefined ? undefined : current.input.listeners[sourceIndex]?.label
    if (label !== previousLabel) item.commentBefore = label ? ` ${JSON.stringify(label)}` : undefined
    return item
  })
  return doc.toString()
}
