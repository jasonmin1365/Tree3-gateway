<script setup lang="ts">
import { toast } from 'vue-sonner'
import {
  buildResidentialProfile,
  parseResidentialSocksUrl,
  ResidentialProfileError,
} from '~/utils/residentialProfile'
import {
  type ResidentialEditInput,
  updateResidentialProfile,
} from '~/utils/residentialProfileEdit'

const props = defineProps<{
  edit?: { id: string; name: string; content: string; input: ResidentialEditInput }
}>()
const emit = defineEmits<{ saved: [id?: string]; cancel: [] }>()
const { t } = useI18n()
const api = useControlApi()
const profileStatus = useProfileStatus()

const profileName = ref(props.edit?.name ?? '')
const busy = ref(false)
const hostError = ref(false)
const saveError = ref('')
const subscriptionVisible = ref(false)
const subscriptionInputId = useId()
let previousHost = props.edit?.input.host ?? ''

const defaults: ResidentialEditInput = {
  host: '',
  port: '',
  username: '',
  password: '',
  chainEnabled: false,
  subscriptionUrl: '',
  listeners: [
    { label: 'GPT', name: 'gpt-in', listen: '0.0.0.0', port: '11001' },
    { label: 'Claude', name: 'claude-in', listen: '0.0.0.0', port: '11002' },
  ],
}
const initial = props.edit?.input ?? defaults
const form = reactive({
  ...initial,
  listeners: initial.listeners.map((row, id) => ({ ...row, id })),
})
watch(() => form.chainEnabled, (enabled) => {
  if (!enabled) subscriptionVisible.value = false
})
let nextListenerId = form.listeners.length

function addListener() {
  form.listeners.push({
    id: nextListenerId++,
    label: '',
    name: '',
    listen: '0.0.0.0',
    port: '',
  })
}

function looksLikeUrl(value: string) {
  return /^[a-z][a-z\d+.-]*:\/\//i.test(value.trim())
}

function applySocksUrl(value: string) {
  try {
    Object.assign(form, parseResidentialSocksUrl(value))
    previousHost = form.host
    hostError.value = false
    return true
  } catch {
    hostError.value = true
    return false
  }
}

function onHostPaste(event: ClipboardEvent) {
  const text = event.clipboardData?.getData('text/plain') || ''
  if (!looksLikeUrl(text)) return
  event.preventDefault()
  applySocksUrl(text)
}

function onHostChange() {
  if (looksLikeUrl(form.host)) {
    if (!applySocksUrl(form.host)) form.host = previousHost
  } else if (!hostError.value) {
    previousHost = form.host
  }
}

async function saveProfile() {
  if (busy.value) return
  saveError.value = ''
  onHostChange()
  if (hostError.value) return

  const edit = props.edit
  let content: string
  try {
    content = edit ? updateResidentialProfile(edit.content, form) : buildResidentialProfile(form)
  } catch (error) {
    saveError.value = error instanceof ResidentialProfileError
      ? t(`residentialProfileError_${error.code}`, { row: error.row ?? 0 })
      : t('residentialProfileSaveFailed')
    return
  }

  busy.value = true
  try {
    if (edit) {
      await api.updateProfile(edit.id, { name: profileName.value.trim() || edit.name, content })
    } else {
      await api.createProfile({
        name: profileName.value.trim() || t(
          form.chainEnabled ? 'residentialProfileChainedName' : 'residentialProfileDirectName',
        ),
        type: 'local',
        content,
      })
    }
  } catch {
    saveError.value = t('residentialProfileSaveFailed')
    return
  } finally {
    busy.value = false
  }

  toast.success(t('residentialProfileSaved'))
  emit('saved', edit?.id)
  void profileStatus.refresh().catch(() => undefined)
}
</script>

<template>
  <details :open="Boolean(edit)" class="mt-4 rounded-lg border border-base-content/10 p-3">
    <summary class="cursor-pointer font-medium">
      {{ t('residentialProfileTitle') }}
    </summary>

    <form class="mt-3 flex flex-col gap-3" @submit.prevent="saveProfile">
      <fieldset class="flex flex-col gap-3" :disabled="busy">
        <label class="flex flex-col gap-1 text-sm">
          <span class="text-base-content/60">{{ t('profilesName') }}</span>
          <input
            v-model="profileName"
            class="input-bordered input w-full input-sm"
            :placeholder="t(form.chainEnabled ? 'residentialProfileChainedName' : 'residentialProfileDirectName')"
          />
        </label>

        <div class="flex flex-col gap-2 sm:flex-row sm:items-end">
          <label class="flex min-w-0 flex-1 flex-col gap-1 text-sm">
            <span class="text-base-content/60">{{ t('residentialProfileHostPort') }}</span>
            <input
              v-model="form.host"
              class="input-bordered input w-full input-sm"
              :placeholder="t('residentialProfileHostHint')"
              :aria-invalid="hostError"
              autocomplete="off"
              spellcheck="false"
              @input="hostError = false"
              @paste="onHostPaste"
              @change="onHostChange"
            />
          </label>
          <input
            v-model="form.port"
            class="input-bordered input w-full input-sm sm:w-28"
            :aria-label="t('residentialProfilePort')"
            :placeholder="t('residentialProfilePort')"
            inputmode="numeric"
          />
        </div>
        <p v-if="hostError" role="alert" class="text-sm text-error">
          {{ t('residentialProfileInvalidUrl') }}
        </p>

        <div class="grid gap-3 sm:grid-cols-2">
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-base-content/60">{{ t('residentialProfileUsername') }}</span>
            <input v-model="form.username" class="input-bordered input w-full input-sm" autocomplete="off" />
          </label>
          <label class="flex flex-col gap-1 text-sm">
            <span class="text-base-content/60">{{ t('residentialProfilePassword') }}</span>
            <input v-model="form.password" class="input-bordered input w-full input-sm" type="password" autocomplete="new-password" />
          </label>
        </div>

        <label class="flex items-center gap-2 text-sm">
          <input v-model="form.chainEnabled" class="toggle toggle-primary toggle-sm" type="checkbox" />
          {{ t('residentialProfileEnableChain') }}
        </label>
        <div v-if="form.chainEnabled" class="flex flex-col gap-1 text-sm">
          <label :for="subscriptionInputId" class="text-base-content/60">
            {{ t('residentialProfileAirportUrl') }}
          </label>
          <div class="flex items-center gap-2">
            <input
              :id="subscriptionInputId"
              v-model="form.subscriptionUrl"
              class="input-bordered input min-w-0 flex-1 input-sm"
              :type="subscriptionVisible ? 'text' : 'password'"
              autocomplete="off"
              spellcheck="false"
              placeholder="https://..."
            />
            <Button
              type="button"
              class="btn-ghost btn-sm shrink-0"
              :aria-controls="subscriptionInputId"
              @click="subscriptionVisible = !subscriptionVisible"
            >
              {{ t(subscriptionVisible ? 'residentialProfileHideSubscription' : 'residentialProfileShowSubscription') }}
            </Button>
          </div>
        </div>

        <div class="flex items-center justify-between gap-2">
          <h3 class="text-sm font-medium">{{ t('residentialProfileListeners') }}</h3>
          <Button type="button" class="btn-ghost btn-sm" @click="addListener">
            {{ t('residentialProfileAddListener') }}
          </Button>
        </div>
        <div
          v-for="(listener, index) in form.listeners"
          :key="listener.id"
          class="grid grid-cols-2 items-end gap-2 rounded-lg border border-base-content/10 p-2 lg:grid-cols-[1fr_1fr_1fr_7rem_auto]"
        >
          <label class="flex min-w-0 flex-col gap-1 text-sm">
            <span class="text-base-content/60">{{ t('residentialProfileListenerLabel') }}</span>
            <input v-model="listener.label" class="input-bordered input w-full input-sm" />
          </label>
          <label class="flex min-w-0 flex-col gap-1 text-sm">
            <span class="text-base-content/60">{{ t('residentialProfileListenerName') }}</span>
            <input v-model="listener.name" class="input-bordered input w-full input-sm" />
          </label>
          <label class="flex min-w-0 flex-col gap-1 text-sm">
            <span class="text-base-content/60">{{ t('residentialProfileListenerAddress') }}</span>
            <input v-model="listener.listen" class="input-bordered input w-full input-sm" />
          </label>
          <label class="flex min-w-0 flex-col gap-1 text-sm">
            <span class="text-base-content/60">{{ t('residentialProfilePort') }}</span>
            <input v-model="listener.port" class="input-bordered input w-full input-sm" inputmode="numeric" />
          </label>
          <Button type="button" class="btn-ghost btn-sm text-error" @click="form.listeners.splice(index, 1)">
            {{ t('residentialProfileRemoveListener') }}
          </Button>
        </div>
        <p class="text-xs text-base-content/60">{{ t('residentialProfilePortHint') }}</p>
      </fieldset>

      <p v-if="saveError" role="alert" class="text-sm text-error">{{ saveError }}</p>
      <div class="flex items-center gap-3">
        <Button type="submit" class="btn-primary btn-sm" :loading="busy" :disabled="busy">
          {{ t(edit ? 'profilesSave' : 'residentialProfileSave') }}
        </Button>
        <Button v-if="edit" type="button" class="btn-ghost btn-sm" :disabled="busy" @click="emit('cancel')">
          {{ t('profilesCancel') }}
        </Button>
        <span v-else class="text-xs text-base-content/60">{{ t('residentialProfileSaveHint') }}</span>
      </div>
    </form>
  </details>
</template>
